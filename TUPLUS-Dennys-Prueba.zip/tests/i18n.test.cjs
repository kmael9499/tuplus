const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict');
const {parseHTML}=require('linkedom');
const base=path.resolve(__dirname,'..','dist');
const pause=()=>new Promise(resolve=>setTimeout(resolve,0));
let checks=0;
async function test(file){
 const {window}=parseHTML(fs.readFileSync(path.join(base,file),'utf8'));
 const document=window.document;
 const picker=document.getElementById('site-language');
 if(picker)Object.defineProperty(picker,'value',{value:'es',writable:true});
 const store=new Map();
 const context=vm.createContext({window,document,scrollY:0,Node:window.Node,NodeFilter:{SHOW_TEXT:4},MutationObserver:window.MutationObserver,CustomEvent:window.CustomEvent,localStorage:{getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v)},matchMedia:()=>({matches:true,addEventListener(){}}),requestAnimationFrame:()=>0,cancelAnimationFrame(){},setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,clearInterval(){},console});
 for(const script of ['js/i18n-data.js','js/site-translations.js','js/quote-translations.js',...(file==='index.html'?['js/contact-translations.js','js/proyectos.js','js/redesign.js']:[]),'js/i18n.js'])vm.runInContext(fs.readFileSync(path.join(base,script),'utf8'),context,{filename:script});
 const api=window.TUPLUS_I18N;
 for(const locale of ['ja','zh','en','ru','pt','fr','de','zh','ja','es','ja','zh','es']){
  api.setLocale(locale);await pause();
  assert.equal(document.documentElement.lang,({zh:'zh-CN',pt:'pt-BR'})[locale]||locale);checks++;
  for(const node of document.querySelectorAll('[data-i18n]')){assert.equal(node.textContent,api.t(node.getAttribute('data-i18n')));checks++;}
  if(file==='index.html'){
   const eyebrow=document.querySelector('#contacto .eyebrow');
   assert.equal(eyebrow.textContent.trim(),api.t('05 / CONSTRUYAMOS LO QUE SIGUE'));checks++;
   if(locale!=='es'){assert.doesNotMatch(eyebrow.textContent,/CONSTRUYAMOS/);checks++;}
   const contact=document.getElementById('contact-title');
   if(locale==='ja'||locale==='zh'){assert.match(contact.textContent,locale==='ja'?/こんにちは/:/你好/);assert.doesNotMatch(contact.textContent,/\ba\b|hola|empiezan/);checks+=2;}
   // La escena de proyectos queda traducida por completo.
   for(const item of document.querySelectorAll('.tp-info .tp-eyebrow,.tp-info h3,.tp-info-text,.tp-info-list li,.tp-final .tp-eyebrow,.tp-final h3,.tp-final p,.tp-final a,.tp-chapters span,.tp-cta')){
    if(locale==='ja'||locale==='zh'){assert.doesNotMatch(item.textContent.replace(/WhatsApp/g,''),/[a-záéíóú]/i);checks++;}
   }
   for(let step=0;step<3;step++){
    document.querySelector('[data-demo-step="1"]')?.click();await pause();
    const title=document.querySelector('.ux-demo-title');
    if(title){assert.equal(title.innerHTML,api.t(title.getAttribute('data-i18n-html')));checks++;}
   }
  }
 }
 // A component overwrites a translated text node with another Spanish source.
 const probe=document.createElement('p');probe.textContent='Conceptos de proyectos';document.body.append(probe);await pause();
 api.setLocale('ja');await pause();assert.equal(probe.textContent,api.t('Conceptos de proyectos'));checks++;
 probe.textContent='Sistemas a medida';api.setLocale('zh');await pause();assert.equal(probe.textContent,api.t('Sistemas a medida'));checks++;
 api.setLocale('es');await pause();assert.equal(probe.textContent,'Sistemas a medida');checks++;
 console.log(file+': OK');
}
(async()=>{for(const file of ['index.html','cotizador.html','privacidad.html','404.html',...fs.readdirSync(path.join(base,'soluciones')).filter(x=>x.endsWith('.html')).map(x=>'soluciones/'+x)])await test(file);console.log(checks+' comprobaciones de traducción correctas');})().catch(error=>{console.error(error);process.exitCode=1;});

