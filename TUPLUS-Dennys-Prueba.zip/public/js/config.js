/* Configuración comercial centralizada. Validar tarifas y canal antes de publicar. */
const TUPLUS_LOCAL_HOSTS = new Set(['localhost', '127.0.0.1', '::1']);
const TUPLUS_LOCAL_API = TUPLUS_LOCAL_HOSTS.has(window.location?.hostname)
  ? window.location.origin
  : '';
window.TUPLUS_CONFIG = Object.freeze({
  quoteBackendEnabled: true, // Guarda cotizaciones y valida cupones en el panel ERP.
  // Panel ERP (Render). Sin esta URL la web funciona igual, sin cupones ni descuentos por fecha.
  apiUrl: TUPLUS_LOCAL_API || 'https://tuplusadminpanel.onrender.com',
  partnersApiUrl: 'https://tuplus-partners-api-production.up.railway.app/api',
  whatsapp: '51916828870',
  // Pagos: completa estos datos antes de publicar.
  payments: {
    // Enlace de tu pasarela (Culqi, Niubiz, Mercado Pago, Stripe Payment Link, etc.).
    gatewayUrl: '',
    crypto: {
      enabled: true,
      // Pega aquí TUS direcciones reales. Verifica cada red antes de publicar.
      // qr: ruta de la imagen del QR, ej. 'imagenes/qr-usdt-trc20.png'.
      wallets: [
        { id: 'usdt-trc20', label: 'USDT · red TRON (TRC-20)', address: '', qr: '' },
        { id: 'usdt-erc20', label: 'USDT · red Ethereum (ERC-20)', address: '', qr: '' },
        { id: 'btc', label: 'Bitcoin (BTC)', address: '', qr: '' }
      ]
    }
  },
  currency: 'PEN',
  locale: 'es-PE',
  pricePerPage: 50,
  maxExtraPages: 20,
  types: {
    corporativa: { name: 'Página corporativa', price: 0 },
    tienda: { name: 'Tienda virtual', price: 350 },
    landing: { name: 'Página de campaña', price: -150 }
  },
  plans: {
    profesional: { name: 'Profesional', price: 950 },
    empresarial: { name: 'Empresarial', price: 1575 },
    corporativo: { name: 'Corporativo', price: 2450 }
  }
});
